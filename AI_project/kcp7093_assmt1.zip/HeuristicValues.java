//CSE4308- Artificial Intelligence: Assignment 1
//Name: Kerry Pacheco ID:1001437093
public class HeuristicValues
{
    private String cityName;
    private float cityHeuristic;

    public void setCityName(String city)
    {
        this.cityName = city;
    }
    public String getCityName()
    {
        return cityName;
    }

    public void setCityHeuristic(float value)
    {
        this.cityHeuristic = value;
    }
    public float getCityHeuristic()
    {
        return cityHeuristic;
    }

}
